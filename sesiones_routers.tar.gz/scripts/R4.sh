conf t
interf eth0.0
no ip addr 192.168.0.1/24
ip addr 10.0.0.6/12
exit
interf eth0.4
no ip addr 192.168.4.1/24
ip addr 10.0.6.160/30
exit
interf eth0.2
no ip addr 192.168.2.1/24
exit
interf eth0.3
no ip addr 192.168.3.1/24
exit
interf eth0.5
no ip addr 192.168.5.1/24
exit
