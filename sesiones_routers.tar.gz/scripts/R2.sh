!#/bin/bash

#Se configura la oficina para poder hacer telnet
sudo ifconfig eth1 192.168.0.5/24
telnet 192.168.0.1

conf t
#Se quitan las interfaces que no se usan
interf eth0.2
no ip addr 192.168.1.1/24
shutdown
exit
interf eth0.4
no ip addr 192.168.4.1/24
shutdown
exit
interf wl0
no ip addr 192.168.5.1/24
shutdown
exit
interf sit0
shutdown
exit
exit

#ESTABLECER TODAS LAS IP NECESARIAS PARA LA TOPOLOGIA
#Una vez quitaradas las subredes que no se usan
#configuramos el resto de interfaces
conf t
#conexion router 1
interface eth0.1
ip address 10.0.6.166/30
no ip address 192.168.1.1/24
exit
#conextion router 3
interface eth0.3
ip address 10.0.6.1/30
no ip addr 192.168.3.1/24
#configuracion subred propia
interface eth0.0
ip address 10.0.6.65/26
exit
exit
quit
#aqui se cae el telnet
sudo ifconfig eth1 10.0.6.66/26
sudo route add -net 10.0.6.0/24  gw 10.0.6.65
telnet 10.0.6.65
conf t
interface eth0.0
no ip address 192.168.0.1/24
exit
exit
#FIN DE ESTABLECIMIENTO DE IP's

#CONFIGURACION DE RIP
conf t
router rip
network 10.0.6.0/24
#Se pasiva la interfaz de la oficina
passive-interface eth0.0 
exit
exit

#### fase ospf
conf t
router ospf
ospf router-id 0.0.6.1
network 10.0.6.0/24 area 10.0.6.0
#Se pasiva la interfaz de la oficina
passive-interface eth0.0
exit
exit





