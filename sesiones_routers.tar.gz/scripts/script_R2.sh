!#/bin/bash
sudo ifconfig eth1 192.168.0.5/24
telnet 192.168.0.1
configure terminal
#conexion servidores, router 3
interface eth0.3
ip address 10.0.6.170/30
no ip addr 192.168.3.1/24
exit
#ruta a servidores
ip route 10.0.6.0/26 10.0.6.169
ip route 10.0.0.0/0 10.0.6.169
#respaldo
ip route 10.0.6.0/26 10.0.6.165 10
ip route 10.0.0.0/0 10.0.6.165 10
#conexion router 1, oficinas 1
interface eth0.1
ip address 10.0.6.166/30
no ip addr 192.168.1.1/24
exit
ip route 10.0.6.128/27 10.0.6.165
#respaldo
ip route 10.0.6.128/27 10.0.6.169 10
#ruta a oficinas PROPIAS
interface eth0.0
ip address 10.0.6.129/27
exit
exit
quit
#aqui se cae el telnet
sudo ifconfig eth1 10.0.6.130/27
sudo route add -net 10.0.6.0/24 gw 10.0.6.129
telnet 10.0.6.129
conf t
interface eth0.0
no ip address 192.168.0.1/24
#todo configurado

#hay que hacer shutdown
#comprobar hito 


########
######## HAY QUE ENCENDER RIP
no ip route 10.0.6.0/26 10.0.6.169
no ip route 10.0.0.0/0 10.0.6.169
no ip route 10.0.6.0/26 10.0.6.165 10
no ip route 10.0.0.0/0 10.0.6.165 10
no ip route 10.0.6.128/27 10.0.6.165
np ip route 10.0.6.128/27 10.0.6.169 10
router rip
network 10.0.6.0/24
##hay que encender ospf
no network 10.0.6.0/24
exit
router ospf
#router id: 0.0.Area.NumeroDeRouter
ospf router-id 0.0.6.2
network 10.0.6.0/24 area 6
