!#/bin/bash

#Se configura la oficina para poder hacer telnet
sudo ifconfig eth1 192.168.0.5/24
telnet 192.168.0.1

conf t
#Se quitan las interfaces que no se usan
interf eth0.1
no ip addr 192.168.1.1/24
shutdown
exit
interf eth0.4
no ip addr 192.168.4.1/24
shutdown
exit
interf wl0
no ip addr 192.168.5.1/24
shutdown
exit
interf sit0
shutdown
exit
exit

#ESTABLECER TODAS LAS IP NECESARIAS PARA LA TOPOLOGIA
#Una vez quitadas las subredes que no se usan
#configuramos el resto de interfaces
conf t
#conexion router 2
interface eth0.2
ip address 10.0.6.165/30
no ip address 192.168.2.1/24
exit
#conextion router 3
interface eth0.3
ip address 10.0.6.173/30
no ip addr 192.168.3.1/24
#configuracion subred propia
interface eth0.0
ip address 10.0.6.65/26
exit
exit
quit
#aqui se cae el telnet
sudo ifconfig eth1 10.0.6.66/26
sudo route add -net 10.0.6.0/24  gw 10.0.6.65
telnet 10.0.6.65
conf t
interface eth0.0
no ip address 192.168.0.1/24
exit
exit
#FIN DE ESTABLECIMIENTO DE IP's

#ESTABLECIMIENTO DE RUTAS CON RESPALDO
conf t
#ruta a oficinas 2
ip route 10.0.6.128/27 10.0.6.166
ip route 10.0.6.128/27 10.0.6.174 10
#ruta a servidores 3 y al resto de la topoligia
ip route 10.0.6.0/26 10.0.6.174
ip route 10.0.0.0/16 10.0.6.174
ip route 10.0.6.0/26 10.0.6.166 10
ip route 10.0.0.0/16 10.0.6.166 10
exit

#BORRADO DE TODAS LAS RUTAS ESTATICAS
conf t
#ruta a oficinas 2
no ip route 10.0.6.128/27 10.0.6.166
no ip route 10.0.6.128/27 10.0.6.174 10
#ruta a servidores 3 y al resto de la topoligia
no ip route 10.0.6.0/26 10.0.6.174
no ip route 10.0.0.0/16 10.0.6.174
no ip route 10.0.6.0/26 10.0.6.166 10
no ip route 10.0.0.0/16 10.0.6.166 10
exit

#CONFIGURACION DE RIP
conf t
router rip
network 10.0.6.0/24
#Se pasiva la interfaz de la oficina
passive-interface eth0.0 
exit
exit

#FASE OSPF
conf t
router ospf
ospf router-id 0.0.6.1
network 10.0.6.0/24 area 10.0.6.0
#Se pasiva la interfaz de la oficina
passive-interface eth0.0
exit
exit





